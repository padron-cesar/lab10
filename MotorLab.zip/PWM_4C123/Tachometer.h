#include <stdint.h>

//set up tach ports
void Tach_Init(void);

//calculate speed from data
uint32_t getSpeed(void);

