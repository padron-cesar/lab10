#include <stdint.h>
#include "../inc/PLL.h"
#include "../inc/PWM.h"
#include "Motor.h"
#include "Button.h"
#include "../inc/ST7735.h"
#include "Tachometer.h"
#include "LCD.h"
#include "Tach.h"
#include <stdlib.h>

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode



int plotX = 0;
void draw_data(uint16_t temp, int color) {
		int plotY = 149 - ((temp) *100 / 550);
		ST7735_DrawPixel(plotX, plotY,color);
		plotX++;
	  if (plotX == 128) {
			plotX = 0;
			ST7735_FillRect(0,50,128,100, ST7735_BLACK);
		}
}

void print_screen(void) {
		ST7735_SetCursor(0,0);
		ST7735_OutString("Desired RPS = ");
		ST7735_sDecOut3(desiredSpeed);
		ST7735_SetCursor(0,1);
		ST7735_OutString("True RPS = ");
		ST7735_sDecOut3(get_speed());

}

int mainMotor(void){
	PLL_Init(Bus80MHz);
	PWM0B_Init(40000, 30000);
	while(1){}
}

int main(void){
  PLL_Init(Bus80MHz);               // bus clock at 80 MHz
	ST7735_InitR(INITR_REDTAB);
	Motor_Init();
	tach_timer_init();
	//Tach_Init();
	Button_Init();
	
	//ST7735_DrawString(0,4,"55 RPS", ST7735_YELLOW);
	//ST7735_DrawString(0,15,"0 RPS", ST7735_YELLOW);
  //EnableInterrupts();

  //PWM0A_Init(40000, 24000);         // initialize PWM0, 1000 Hz, 75% duty
  //PWM0A_Duty(4000);    // 10%
//  PWM0_Duty(10000);   // 25%
//  PWM0_Duty(30000);   // 75%

  //PWM0A_Init(4000, 2000);         // initialize PWM0, 10000 Hz, 50% duty
  //PWM0B_Init(1000, 900);          // initialize PWM0, 40000 Hz, 90% duty
  //PWM0_Init(1000, 100);          // initialize PWM0, 40000 Hz, 10% duty
//  PWM0_Init(40, 20);             // initialize PWM0, 1 MHz, 50% duty
	
  while(1){
		WaitForInterrupt(); 
    print_screen();
		draw_data(get_speed(), ST7735_BLUE);
		draw_data(desiredSpeed,ST7735_RED );
  }
}

