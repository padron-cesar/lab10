
#include <stdint.h>

//set up motor ports
void Motor_Init(void);

//set duty cycle
void PWM_Duty(uint16_t duty);

//turn motor on
void Motor_On(void);

extern int32_t desiredSpeed;

