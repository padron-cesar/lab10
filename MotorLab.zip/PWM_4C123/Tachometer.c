#include <stdint.h>
#include "Tachometer.h"
#include "../inc/tm4c123gh6pm.h"
#include "../inc/ST7735.h"

#define PF2                     (*((volatile uint32_t *)0x40025010))
#define TIMER_TAMR_TACMR        0x00000004  // GPTM TimerA Capture Mode
#define TIMER_TAMR_TAMR_CAP     0x00000003  // Capture mode
#define TIMER_CTL_TAEN          0x00000001  // GPTM TimerA Enable
#define TIMER_CTL_TAEVENT_POS   0x00000000  // Positive edge
#define TIMER_CTL_TAEVENT_NEG   0x00000004  // Negative edge
#define TIMER_CTL_TAEVENT_BOTH  0x0000000C  // Both edges
#define TIMER_IMR_CAEIM         0x00000004  // GPTM CaptureA Event Interrupt
#define TIMER_TAILR_TAILRL_M    0x0000FFFF  // GPTM TimerA Interval Load
#define NVIC_EN0_INT19          0x00080000  // Interrupt 19 enable

uint32_t Period;              // (1/clock) units
uint32_t First;               // Timer0A first edge
int32_t Done;                 // set each rising 

void EnableInterrupts(void);  // Enable interrupts
void DisableInterrupts(void); // Disable interrupts


void Tach_Init(void) {
  SYSCTL_RCGCTIMER_R |= 0x01;// activate timer0    
  SYSCTL_RCGCGPIO_R |= 0x22;       // activate port B and port F
                                   // allow time to finish activating
  First = 0;                       // first will be wrong
  Done = 0;                        // set on subsequent
  GPIO_PORTB_DIR_R &= ~0x20;       // make PB5 in
  GPIO_PORTB_AFSEL_R |= 0x20;      // enable alt funct on PB5/T0CCP0
  GPIO_PORTB_DEN_R |= 0x20;        // enable digital I/O on PB5
                                   // configure PB5 as T0CCP0
  GPIO_PORTB_PCTL_R = (GPIO_PORTB_PCTL_R&0xFF0FFFF)+0x00700000;
  GPIO_PORTB_AMSEL_R &= ~0x20;     // disable analog functionality on PB5
  GPIO_PORTF_DIR_R |= 0x04;        // make PF2 out (PF2 built-in blue LED)
  GPIO_PORTF_AFSEL_R &= ~0x04;     // disable alt funct on PF2
  GPIO_PORTF_DEN_R |= 0x04;        // enable digital I/O on PF2
                                   // configure PF2 as GPIO
  GPIO_PORTF_PCTL_R = (GPIO_PORTF_PCTL_R&0xFFFFF0FF)+0x00000000;
  GPIO_PORTF_AMSEL_R = 0;          // disable analog functionality on PF
	
	TIMER0_CTL_R &= ~0x00000001;     // disable timer0A during setup
  TIMER0_CFG_R = 0x00000004;       // configure for 16-bit capture mode
  TIMER0_TAMR_R = TIMER_TAMR_TAMR_PERIOD;      // configure for rising edge event
  TIMER0_CTL_R &= ~0x0000000C;     // rising edge
  TIMER0_TAILR_R = 0x00FFFFFF;     // start value
  TIMER0_TAPR_R = 0xFF;            // activate prescale, creating 24-bit 
  TIMER0_IMR_R |= 0x00000001;      // enable capture match interrupt
  TIMER0_ICR_R = 0x00000001;       // clear timer0A capture match flag
  TIMER0_CTL_R |= 0x00000001;      // timer0A 24-b, +edge, interrupts
  NVIC_PRI4_R = (NVIC_PRI4_R&0x00FFFFFF)|0x40000000; //Timer0A=priority 2
  NVIC_EN0_R = 1<<19;              // enable interrupt 19 in NVIC
}

void Timer0A1_Handler(void){
	//PF2 = PF2^0x04;  // toggle PF2
  TIMER0_ICR_R = TIMER_ICR_CAECINT;// acknowledge timer0A capture match
	uint32_t cur = TIMER0_TBR_R;

	if(First < cur){
		First = First + 0x00FFFFFF;
	}
  Period = (First - TIMER0_TAR_R)&0xFFFFFF;// 24 bits, 12.5ns resolution
  First = TIMER0_TAR_R;            // setup for next
  Done = 1;
	//PF2 = PF2^0x04;  // toggle PF2
}

// fixed-point
// resolution = 0.1
uint32_t getSpeed(void) {
	uint32_t speed = 800000000/(4*Period);
	return speed;
}

