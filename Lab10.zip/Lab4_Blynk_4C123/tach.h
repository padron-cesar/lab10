#include <stdint.h>

void init_tach(void);
void tach_timer_init(void);
uint32_t get_speed(void);

